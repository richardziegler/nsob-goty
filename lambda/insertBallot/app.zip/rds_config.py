#config file containing credentials for rds mysql instance
db_username = "admin"
db_password = "admingamer"
db_name = "nsobgoty" 